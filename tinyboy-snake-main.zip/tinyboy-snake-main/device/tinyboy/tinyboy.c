
#include "../../include.h"

#include "tinyboy_disp.c"
#include "tinyboy_draw.c"
#include "tinyboy_key.c"
#include "tinyboy_snd.c"
#include "tinyboy_bat.c"
#include "tinyboy_init.c"


